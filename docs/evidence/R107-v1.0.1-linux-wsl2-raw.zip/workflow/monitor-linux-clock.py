import json,sys,time
with open(sys.argv[1],'x',buffering=1) as f:
 while True:
  m0=time.monotonic_ns(); w=time.time_ns(); m1=time.monotonic_ns()
  f.write(json.dumps({'monotonic_before_ns':m0,'wall_ns':w,'monotonic_after_ns':m1})+'\n')
  time.sleep(.02)