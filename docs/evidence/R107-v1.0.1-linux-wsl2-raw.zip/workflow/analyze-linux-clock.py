import json,pathlib
b=pathlib.Path('/var/tmp/sider-recovery-107-v1.0.1')
p=b/'clock-attempt-2.jsonl'
rows=[json.loads(x) for x in p.read_text().splitlines()]
offsets=[x['wall_ns']-(x['monotonic_before_ns']+x['monotonic_after_ns'])//2 for x in rows]
print(json.dumps({'samples':len(rows),'elapsed_monotonic_ms':(rows[-1]['monotonic_before_ns']-rows[0]['monotonic_before_ns'])/1e6,'offset_net_change_ms':(offsets[-1]-offsets[0])/1e6,'offset_range_ms':(max(offsets)-min(offsets))/1e6,'max_adjacent_offset_change_ms':max(abs(b-a) for a,b in zip(offsets,offsets[1:]))/1e6},indent=2))
phases=b/'linux-wsl2-attempt-2/phases.jsonl'
for l in phases.read_text().splitlines():
 x=json.loads(l)
 if x['phase'] in ['ttl_anchor','ttl_diagnostic']: print(json.dumps(x,indent=2))
print((b/'linux-wsl2-attempt-2-cargo.log').read_text()[-1800:])