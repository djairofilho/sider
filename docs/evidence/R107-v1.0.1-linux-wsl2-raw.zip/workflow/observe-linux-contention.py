import json,pathlib,subprocess,time,os
base=pathlib.Path('/var/tmp/sider-recovery-107-v1.0.1')
root=base/'linux-wsl2-attempt-3'
out=root/'background-activity.jsonl'
rows=subprocess.run(['ps','-p','1634','-o','pid,etimes,pcpu,cputime,args'],text=True,capture_output=True)
entry={'observed_unix_ms':time.time_ns()//1000000,'observed_monotonic_ns':time.monotonic_ns(),'process_sample_stdout':rows.stdout,'process_sample_stderr':rows.stderr,'process_sample_exit':rows.returncode,'first_observed_pid':1634,'first_observed_cpu_percent':102.0,'first_observed_elapsed_seconds':55,'first_observed_test_elapsed_seconds':413,'timing_qualification':'Automatic Ubuntu unattended upgrades competed during final Linux run. No idle-host or Windows timing comparison claim. Functional oracles remain the acceptance criterion.'}
def start_ticks(pid):
 try: return int(pathlib.Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()[19])
 except FileNotFoundError: return None
updater_start=start_ticks(1634); harness_start=start_ticks(1316)
entry['updater_start_ticks']=updater_start
entry['harness_start_ticks']=harness_start
entry['clock_ticks_per_second']=os.sysconf('SC_CLK_TCK')
entry['overlap_start_relative_to_harness_seconds']=(updater_start-harness_start)/os.sysconf('SC_CLK_TCK') if updater_start is not None and harness_start is not None else None
with out.open('a') as f: f.write(json.dumps(entry)+'\n')
subprocess.run(['ps','-eo','pid,etimes,pcpu,comm'],stdout=(base/'background-process-sample.log').open('a'),check=True)
print(json.dumps(entry,indent=2))