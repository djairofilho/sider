#!/usr/bin/env bash
set -euo pipefail
export PATH="$HOME/.cargo/bin:$PATH"
export CARGO_BUILD_JOBS=2
base=/var/tmp/sider-recovery-107-v1.0.1
repo=/tmp/sider-recovery-107-runner
inputs=/mnt/c/Users/Usuario/AppData/Local/Temp/sider-recovery-107-v1.0.1
mkdir "$base"
trap 'drill_exit=$?; cp "$base"/*.log "$inputs/" 2>/dev/null || true; printf "Linux workflow exit %s\n" "$drill_exit"' EXIT
git -c safe.directory=/mnt/c/Users/Usuario/Documents/Coding/sider clone --no-hardlinks --no-checkout /mnt/c/Users/Usuario/Documents/Coding/sider "$repo" > "$base/clone.log" 2>&1
cd "$repo"
git checkout --detach 0f0f232f56fd42b88a56e61954f2bc892458f04d >> "$base/clone.log" 2>&1
cp /mnt/c/Users/Usuario/Documents/Coding/sider-wt-recovery/tests/recovery_drill.rs tests/recovery_drill.rs
cp "$inputs/release-manifest.json" "$inputs/SHA256SUMS" "$inputs/sider-v1.0.1-x86_64-unknown-linux-gnu.tar.gz" "$base/"
cd "$base"
printf '%s  %s\n' acc9520e120d5960c286a184d8e0079774398ad4479610cd9e6a540f5274243d sider-v1.0.1-x86_64-unknown-linux-gnu.tar.gz | sha256sum -c -
tar -xzf sider-v1.0.1-x86_64-unknown-linux-gnu.tar.gz
{ cat /etc/os-release; uname -a; lscpu; free -b; lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS; findmnt -T /var/tmp; df -T /tmp /var/tmp; rustup toolchain list; cargo --version; git -C "$repo" rev-parse HEAD; sha256sum "$repo/tests/recovery_drill.rs"; } > host-observations.log
python3 - <<'PY'
import json, subprocess
s=lambda *a: subprocess.check_output(a,text=True).strip()
mem=int(next(line.split()[1] for line in open('/proc/meminfo') if line.startswith('MemTotal:')))*1024
context={'os':'Ubuntu 24.04.4 LTS x86_64 GNU on WSL2','kernel':s('uname','-a'),'cpu':s('bash','-lc',"lscpu | sed -n '/Model name:/p; /CPU(s):/p'"),'ram_bytes':mem,'storage':'WSL2 ext4 virtual disk /dev/sdg, hosted on Windows local storage; no bare-metal storage measurement','filesystem':s('findmnt','-n','-o','FSTYPE,SOURCE,TARGET','-T','/var/tmp'),'workload_isolation':'no competing benchmark, build, or load test','virtualization':'WSL2 Microsoft kernel on Windows 11 Pro 10.0.26300','representativity':'Linux package functional exercise on WSL2/ext4; not Ubuntu bare metal, power loss, or physical storage durability','package_release':'https://github.com/djairofilho/sider/releases/tag/v1.0.1','shutdown':'SIGKILL of exact owned child PID','runner_build_jobs':2,'retention':'/var/tmp survives temporary /tmp boot cleanup; large files not versioned'}
with open('context.json','w') as f: json.dump(context,f,indent=2)
PY
cd "$repo"
cargo test --locked --test recovery_drill -- --nocapture > "$base/native-contracts.log" 2>&1
printf '%s\n' 'Linux native contracts succeeded'
cargo clippy --locked --test recovery_drill -- -D warnings > "$base/native-clippy.log" 2>&1
printf '%s\n' 'Linux focused Clippy succeeded'
export SIDER_DRILL_PACKAGE_DIR="$base/sider-v1.0.1-x86_64-unknown-linux-gnu"
export SIDER_DRILL_ARCHIVE="$base/sider-v1.0.1-x86_64-unknown-linux-gnu.tar.gz"
export SIDER_DRILL_MANIFEST="$base/release-manifest.json"
export SIDER_DRILL_SHA256SUMS="$base/SHA256SUMS"
export SIDER_DRILL_SOURCE_SHA=b738a0b4f97074fe272bc21f1eacf5db93cd020e
export SIDER_DRILL_CONTEXT="$base/context.json"
export SIDER_DRILL_EVIDENCE="$base/linux-wsl2-attempt-1"
set +e
cargo test --locked --test recovery_drill -- --ignored --exact extracted_package_operator_recovery_drill --nocapture > "$base/linux-wsl2-attempt-1-cargo.log" 2>&1
drill_exit=$?
set -e
printf '%s\n' "$drill_exit" > "$base/linux-wsl2-attempt-1-cargo-exit.txt"
cat "$SIDER_DRILL_EVIDENCE/result.json"
test "$drill_exit" -eq 0