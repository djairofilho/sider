import pathlib,json,struct,datetime
r=pathlib.Path('/var/tmp/sider-recovery-107-v1.0.1/linux-wsl2-attempt-1')
for n in ['primary.stderr','restored.stderr','primary-ready.json','restored-ready.json','primary-command.json','restored-command.json']:
 print(n); print((r/'shards-1'/n).read_text())
for f in [r/'shards-1/backup/snapshot.aof',*sorted((r/'shards-1/primary').glob('*.aof')),*sorted((r/'shards-1/restored').glob('*.aof'))]:
 b=f.read_bytes(); key=b'{types}:long'; pos=0
 while True:
  p=b.find(key,pos)
  if p<0: break
  vlen=struct.unpack_from('<I',b,p+len(key))[0]
  tagpos=p+len(key)+4+vlen
  deadline=struct.unpack_from('<q',b,tagpos+1)[0]
  print(str(f),p,'vlen',vlen,'expiresflag',b[tagpos],'absolute_deadline_ms',deadline,'deadline_utc',datetime.datetime.fromtimestamp(deadline/1000,datetime.timezone.utc).isoformat())
  pos=p+len(key)