#!/usr/bin/env bash
set -euo pipefail
export PATH="$HOME/.cargo/bin:$PATH"
export CARGO_BUILD_JOBS=2
base=/var/tmp/sider-recovery-107-v1.0.1
repo=/var/tmp/sider-recovery-107-runner
inputs=/mnt/c/Users/Usuario/AppData/Local/Temp/sider-recovery-107-v1.0.1
trap 'drill_exit=$?; cp "$base"/*.log "$inputs/" 2>/dev/null || true; printf "Linux final workflow exit %s\n" "$drill_exit"' EXIT
cp /mnt/c/Users/Usuario/Documents/Coding/sider-wt-recovery/tests/recovery_drill.rs "$repo/tests/recovery_drill.rs"
cd "$repo"
cargo test --locked --test recovery_drill -- --nocapture > "$base/native-contracts-final.log" 2>&1
cargo clippy --locked --test recovery_drill -- -D warnings > "$base/native-clippy-final.log" 2>&1
printf '%s\n' 'Linux final contracts and Clippy passed'
export SIDER_DRILL_PACKAGE_DIR="$base/sider-v1.0.1-x86_64-unknown-linux-gnu"
export SIDER_DRILL_ARCHIVE="$base/sider-v1.0.1-x86_64-unknown-linux-gnu.tar.gz"
export SIDER_DRILL_MANIFEST="$base/release-manifest.json"
export SIDER_DRILL_SHA256SUMS="$base/SHA256SUMS"
export SIDER_DRILL_SOURCE_SHA=b738a0b4f97074fe272bc21f1eacf5db93cd020e
export SIDER_DRILL_CONTEXT="$base/context.json"
export SIDER_DRILL_EVIDENCE="$base/linux-wsl2-attempt-3"
python3 /mnt/c/Users/Usuario/AppData/Local/Temp/sider-recovery-107-v1.0.1/monitor-linux-clock.py "$base/clock-attempt-3.jsonl" &
clock_pid=$!
set +e
cargo test --locked --test recovery_drill -- --ignored --exact extracted_package_operator_recovery_drill --nocapture > "$base/linux-wsl2-attempt-3-cargo.log" 2>&1
drill_exit=$?
set -e
kill "$clock_pid"
wait "$clock_pid" || true
printf '%s\n' "$drill_exit" > "$base/linux-wsl2-attempt-3-cargo-exit.txt"
cat "$SIDER_DRILL_EVIDENCE/result.json"
test "$drill_exit" -eq 0