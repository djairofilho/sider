# Derived-index screening

Source SHA: `0d88504c2db54059423cd1cd5c666592c0316ae4`; corpus SHA-256: `16ae499aae3ce7a8c1541789d134c1f11dfe523a986fbf8cec0bda1beae74167`.
Platform: `Linux-6.6.87.2-microsoft-standard-WSL2-x86_64-with-glibc2.35`; Python: `3.10.12`; logical CPUs: `8`.
Seed: `1142026`; 100 repetitions of 37 query shapes per method and size.
Raw results: [raw.json](raw.json).

| Records | Method | Mean/min recall@10 | p50/p95/p99, ms | Queries/s | Serialized index bytes | Median build, ms | Max sampled process RSS, bytes |
| ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 256 | exact | 1.000/1.000 | 0.240/0.443/0.543 | 4413 | 0 | 0.001 | 22482944 |
| 256 | grid_1_probe | 0.527/0.100 | 0.024/0.051/0.072 | 33075 | 1921 | 0.934 | 22745088 |
| 256 | grid_4_probes | 0.980/0.800 | 0.068/0.137/0.184 | 13249 | 1921 | 1.631 | 22876160 |
| 256 | x_window_64 | 0.797/0.400 | 0.105/0.223/0.287 | 7817 | 7391 | 0.095 | 23314432 |
| 1024 | exact | 1.000/1.000 | 1.147/2.211/3.013 | 899 | 0 | 0.001 | 24231936 |
| 1024 | grid_1_probe | 0.650/0.000 | 0.075/0.126/0.189 | 12319 | 7297 | 3.930 | 24363008 |
| 1024 | grid_4_probes | 1.000/1.000 | 0.285/0.383/0.587 | 3778 | 7297 | 4.941 | 24494080 |
| 1024 | x_window_64 | 0.450/0.200 | 0.090/0.117/0.145 | 11301 | 29463 | 0.404 | 24625152 |

The exact method is the quality oracle. Index recall is computed against its top-k
IDs after the same namespace and metadata filters. Grid storage is a serialized
prototype size; Python allocation peaks and lifecycle rebuild timings are in
the raw file. Sider server baselines from #112 are referenced there with exact
SHA and binary identity, but these in-process timings are not directly comparable.
The prototype does not implement Sider persistence or replication. A later
production index would need independent durable and replica validation.
