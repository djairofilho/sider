# Derived-index screening

Source SHA: `0d88504c2db54059423cd1cd5c666592c0316ae4`; corpus SHA-256: `16ae499aae3ce7a8c1541789d134c1f11dfe523a986fbf8cec0bda1beae74167`.
Platform: `Windows-10-10.0.26300-SP0`; Python: `3.11.9`; logical CPUs: `8`.
Seed: `1142026`; 100 repetitions of 37 query shapes per method and size.
Raw results: [raw.json](raw.json).

| Records | Method | Mean/min recall@10 | p50/p95/p99, ms | Queries/s | Serialized index bytes | Median build, ms | Max sampled process RSS, bytes |
| ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 256 | exact | 1.000/1.000 | 0.361/0.851/1.296 | 2198 | 0 | 0.003 | 26062848 |
| 256 | grid_1_probe | 0.527/0.100 | 0.031/0.058/0.080 | 27930 | 1921 | 2.848 | 26202112 |
| 256 | grid_4_probes | 0.980/0.800 | 0.075/0.125/0.173 | 12736 | 1921 | 3.812 | 26341376 |
| 256 | x_window_64 | 0.797/0.400 | 0.089/0.125/0.178 | 11360 | 7391 | 0.106 | 26636288 |
| 1024 | exact | 1.000/1.000 | 1.247/2.398/2.829 | 831 | 0 | 0.002 | 27455488 |
| 1024 | grid_1_probe | 0.650/0.000 | 0.082/0.169/0.207 | 11176 | 7297 | 14.877 | 27742208 |
| 1024 | grid_4_probes | 1.000/1.000 | 0.305/0.519/0.735 | 3308 | 7297 | 9.393 | 27979776 |
| 1024 | x_window_64 | 0.450/0.200 | 0.100/0.220/0.292 | 7779 | 29463 | 0.767 | 28397568 |

The exact method is the quality oracle. Index recall is computed against its top-k
IDs after the same namespace and metadata filters. Grid storage is a serialized
prototype size; Python allocation peaks and lifecycle rebuild timings are in
the raw file. Sider server baselines from #112 are referenced there with exact
SHA and binary identity, but these in-process timings are not directly comparable.
The prototype does not implement Sider persistence or replication. A later
production index would need independent durable and replica validation.
