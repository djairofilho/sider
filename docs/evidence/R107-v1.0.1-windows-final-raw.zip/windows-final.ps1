$ErrorActionPreference = 'Stop'
$drillBase = 'C:\Users\Usuario\AppData\Local\Temp\sider-recovery-107-v1.0.1'
Set-Location -LiteralPath 'C:\Users\Usuario\Documents\Coding\sider-wt-recovery'
function Invoke-DrillCargo([string]$drillLog, [string[]]$drillCommandArgs) {
 $ErrorActionPreference = 'Continue'
 & cargo @drillCommandArgs *> $drillLog
 return $LASTEXITCODE
}
$drillNativeExit = Invoke-DrillCargo (Join-Path $drillBase 'windows-native-contracts-final.log') @('test','--locked','--test','recovery_drill','--','--nocapture')
if ($drillNativeExit -ne 0) { throw 'Final Windows contracts failed' }
$drillNativeExit = Invoke-DrillCargo (Join-Path $drillBase 'windows-native-clippy-final.log') @('clippy','--locked','--test','recovery_drill','--','-D','warnings')
if ($drillNativeExit -ne 0) { throw 'Final Windows Clippy failed' }
$env:SIDER_DRILL_PACKAGE_DIR = Join-Path $drillBase 'sider-v1.0.1-x86_64-pc-windows-msvc'
$env:SIDER_DRILL_ARCHIVE = Join-Path $drillBase 'sider-v1.0.1-x86_64-pc-windows-msvc.zip'
$env:SIDER_DRILL_MANIFEST = Join-Path $drillBase 'release-manifest.json'
$env:SIDER_DRILL_SHA256SUMS = Join-Path $drillBase 'SHA256SUMS'
$env:SIDER_DRILL_SOURCE_SHA = 'b738a0b4f97074fe272bc21f1eacf5db93cd020e'
$env:SIDER_DRILL_CONTEXT = Join-Path $drillBase 'context-windows-final.json'
$env:SIDER_DRILL_EVIDENCE = Join-Path $drillBase 'windows-attempt-3'
$drillExit = Invoke-DrillCargo (Join-Path $drillBase 'windows-attempt-3-cargo.log') @('test','--locked','--test','recovery_drill','--','--ignored','--exact','extracted_package_operator_recovery_drill','--nocapture')
[System.IO.File]::WriteAllText((Join-Path $drillBase 'windows-attempt-3-cargo-exit.txt'), [string]$drillExit + "`n", [System.Text.UTF8Encoding]::new($false))
Get-Content -Raw -Encoding UTF8 -LiteralPath (Join-Path $env:SIDER_DRILL_EVIDENCE 'result.json')
if ($drillExit -ne 0) { throw "Final Windows drill failed: $drillExit" }